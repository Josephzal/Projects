//Joseph Lombardo 7/24/2020
package edu.seminolestate.manageproperties;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import edu.seminolestate.properties.Apartment;
import edu.seminolestate.properties.House;
import edu.seminolestate.properties.IllegalPropertyArgumentException;
import edu.seminolestate.properties.Property;
import edu.seminolestate.properties.PropertyAddressComparator;

public class ManageProperties {
	
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		ArrayList<Property> properties = new ArrayList<>();	
		File objectFile = new File("properties.dat");
		int x = 0;
		
		if(objectFile.exists()) {
			try(FileInputStream fiStream = new FileInputStream(objectFile);
					ObjectInputStream oiStream = new ObjectInputStream(fiStream);) {
					while(true) {
						Property p = (Property) oiStream.readObject();
						properties.add(p);
					}
					}catch(EOFException e) {	
					} catch (IOException e) {
						e.printStackTrace();
						System.exit(-1);
					} catch (ClassNotFoundException e) {
						e.printStackTrace();
						System.exit(-1);
					}
		}
			
		while(true) {
			
			try {
			
			System.out.println("Enter your choice: " + 
								"\n1. Add house" + 
								"\n2. Add apartment" + 
								"\n3. List all properties by ID" + 
								"\n4. List all properties by address" +
								"\n5. Exit");
			
			String choice = input.nextLine();
			x = Integer.parseInt(choice);
			
			}catch(NumberFormatException e) {
				System.out.println("\nInvalid value. Must enter 1-5\n");
				continue;
			}
			
			//1. ADD HOUSE
			if(x == 1) {
				addHouse(properties);
			}
			
			//2. ADD APARTMENT
			else if(x == 2) {
				addApartment(properties);
			}
			
			//3. LIST ALL PROPERTIES BY ID
			else if(x == 3) {
				listID(properties);
			}
			
			//4. LIST ALL PROPERTIES BY ADDRESS
			else if(x == 4) {
				listAddress(properties);
			}
			
			//5. EXIT
			else if(x == 5) {
//				System.out.println("Thank you for using properties program.");
//				break;
			exitProg(properties, objectFile);
			}
			
			//INVALID KEY
			else {
				System.out.println("\nInvalid value. Must enter 1 - 5\n");
			}
			
			
		}
		
		
	}// END MAIN
	
	//OPTION 1
	public static void addHouse(ArrayList<Property> list) {
		
		Scanner input = new Scanner(System.in);
		int ID = 0;
		String address = null;
		double baths = 0;
		int beds = 0;
		double lotSize = 0;
		double value = 0;
		boolean isValidID = false;
		boolean isValidBaths = false;
		boolean isValidBeds = false;
		boolean isValidLotSize = false;
		boolean isValidValue = false;
		String sID = null;
		String sBaths = null;
		String sBeds = null;
		String sLotSize = null;
		String sValue = null;
		
		//ID PROMPT
		while(isValidID == false) {
			System.out.print("Enter property ID: ");
			sID = input.nextLine();
					
			//TRY CATCH BLOCK CONVERTS USER STRING TO INT, USES A 
			//BOOLEAN TO DETERMINE IF THE INT CAUSES EXCEPTION
			//IF NOT, IT DETERMINES THAT THE INPUT IS VALID
			try {
				ID = Integer.valueOf(sID);
				if(ID <=0) {
					System.out.println("ID must be > 0.");
					continue;
				}
				isValidID = true;
			}
			catch(NumberFormatException ex) {
				System.out.println("Enter only integer numbers.");
				continue;
			}
			continue;					
		}
				
		//ADDRESS PROMPT
		while(true) {
			System.out.print("Enter property address: ");
			address = input.nextLine();
			if(address.equals("")) {
				System.out.println("Must enter a value.");
			}
			else
				break;
		}
				
		//BATHS PROMPT
		while(isValidBaths == false) {
			System.out.print("Enter amount of property baths: ");
			sBaths = input.nextLine();
			
			//TRY CATCH BLOCK CONVERTS USER STRING TO DOUBLE, USES A 
			//BOOLEAN TO DETERMINE IF THE INT CAUSES EXCEPTION
			//IF NOT, IT DETERMINES THAT THE INPUT IS VALID
			try {
				baths = Double.valueOf(sBaths);
				if(baths <=0) {
					System.out.println("Baths must be > 0.");
					continue;
				}
				isValidBaths = true;
			}
			catch(NumberFormatException ex) {
				System.out.println("Enter only decimal numbers.");
				continue;
			}
			continue;				
		}
				
		//BEDS PROMPT
		while(isValidBeds == false) {
			System.out.print("Enter amount of property bedrooms: ");
			sBeds = input.nextLine();
					
			//TRY CATCH BLOCK CONVERTS USER STRING TO INT, USES A 
			//BOOLEAN TO DETERMINE IF THE INT CAUSES EXCEPTION
			//IF NOT, IT DETERMINES THAT THE INPUT IS VALID
			try {
				beds = Integer.valueOf(sBeds);
				if(beds <=0) {
					System.out.println("Beds must be > 0.");
					continue;
				}
				isValidBeds = true;
			}
			catch(NumberFormatException ex) {
				System.out.println("Enter only integer numbers.");
				continue;
			}
			continue;			
		}
			
		//LOTSIZE PROMPT
		while(isValidLotSize == false) {
			System.out.print("Enter property lot size: ");
			sLotSize = input.nextLine();
			
			//TRY CATCH BLOCK CONVERTS USER STRING TO DOUBLE, USES A 
			//BOOLEAN TO DETERMINE IF THE INT CAUSES EXCEPTION
			//IF NOT, IT DETERMINES THAT THE INPUT IS VALID
			try {
				lotSize = Double.valueOf(sLotSize);
				if(lotSize <=0) {
					System.out.println("Lot size must be > 0.");
					continue;
				}
				isValidLotSize = true;
			}
			catch(NumberFormatException ex) {
				System.out.println("Enter only decimal numbers.");
				continue;
			}
			continue;			
		}		
				
		//VALUE PROMPT
		while(isValidValue == false) {
			System.out.print("Enter property value (dollars and cents): ");
			sValue = input.nextLine();
			
			//TRY CATCH BLOCK CONVERTS USER STRING TO DOUBLE, USES A 
			//BOOLEAN TO DETERMINE IF THE INT CAUSES EXCEPTION
			//IF NOT, IT DETERMINES THAT THE INPUT IS VALID
			try {
				value = Double.valueOf(sValue);
				if(value <=0) {
					System.out.println("Value must be > 0.");
					continue;
				}
				isValidValue = true;
			}
			catch(NumberFormatException ex) {
				System.out.println("Enter only decimal numbers.");
				continue;
			}
			continue;			
		}
		
		try {
			list.add(new House(ID, address, baths, beds, lotSize, value));
		} catch (IllegalPropertyArgumentException e) {	
			e.printStackTrace();
		}
	}
	
	//OPTION 2
	public static void addApartment(ArrayList<Property> list) {
		
		Scanner input = new Scanner(System.in);
		int ID = 0;
		String address = null;
		double baths = 0;
		int beds = 0;
		double rent = 0;
		boolean isValidID = false;
		boolean isValidBaths = false;
		boolean isValidBeds = false;
		boolean isValidRent = false;
		String sID = null;
		String sBaths = null;
		String sBeds = null;
		String sRent = null;
		
		//ID PROMPT
		while(isValidID == false) {
			System.out.print("Enter property ID: ");
			sID = input.nextLine();
			
			//TRY CATCH BLOCK CONVERTS USER STRING TO INT, USES A 
			//BOOLEAN TO DETERMINE IF THE INT CAUSES EXCEPTION
			//IF NOT, IT DETERMINES THAT THE INPUT IS VALID
			try {
				ID = Integer.valueOf(sID);
				if(ID <=0) {
					System.out.println("ID must be > 0.");
					continue;
				}
				isValidID = true;
			}
			catch(NumberFormatException ex) {
				System.out.println("Enter only integer numbers.");
				continue;
			}
			continue;			
		}
		
		//ADDRESS PROMPT
		while(true) {
			System.out.print("Enter property address: ");
			address = input.nextLine();
			if(address.equals("")) {
				System.out.println("Must enter a value.");
			}
			else
				break;
		}
		
		//BATHS PROMPT
		while(isValidBaths == false) {
			System.out.print("Enter amount of property baths: ");
			sBaths = input.nextLine();
			
			//TRY CATCH BLOCK CONVERTS USER STRING TO DOUBLE, USES A 
			//BOOLEAN TO DETERMINE IF THE INT CAUSES EXCEPTION
			//IF NOT, IT DETERMINES THAT THE INPUT IS VALID
			try {
				baths = Double.valueOf(sBaths);
				if(baths <=0) {
					System.out.println("Baths must be > 0.");
					continue;
				}
				isValidBaths = true;
			}
			catch(NumberFormatException ex) {
				System.out.println("Enter only decimal numbers.");
				continue;
			}
			continue;			
		}
		
		//BEDS PROMPT
		while(isValidBeds == false) {
			System.out.print("Enter amount of property bedrooms: ");
			sBeds = input.nextLine();
			
			//TRY CATCH BLOCK CONVERTS USER STRING TO INT, USES A 
			//BOOLEAN TO DETERMINE IF THE INT CAUSES EXCEPTION
			//IF NOT, IT DETERMINES THAT THE INPUT IS VALID
			try {
				beds = Integer.valueOf(sBeds);
				if(beds <=0) {
					System.out.println("Beds must be > 0.");
					continue;
				}
				isValidBeds = true;
			}
			catch(NumberFormatException ex) {
				System.out.println("Enter only integer numbers.");
				continue;
			}
			continue;			
		}				
		
		//RENT PROMPT
		while(isValidRent == false) {
			System.out.print("Enter amount of property rent: ");
			sRent = input.nextLine();
			
			//TRY CATCH BLOCK CONVERTS USER STRING TO DOUBLE, USES A 
			//BOOLEAN TO DETERMINE IF THE INT CAUSES EXCEPTION
			//IF NOT, IT DETERMINES THAT THE INPUT IS VALID
			try {
				rent = Double.valueOf(sRent);
				if(rent <=0) {
					System.out.println("Rent must be > 0.");
					continue;
				}
				isValidRent = true;
			}
			catch(NumberFormatException ex) {
				System.out.println("Enter only decimal numbers.");
				continue;
			}
			continue;			
		}	
		
		//TRY CATCH BLOCK TAKES USER INPUT, AFTER BEING DEEMED VALID
		//AND ATTEMPTS TO PUT IT INTO THE ARRAYLIST 
		try {
			list.add(new Apartment(ID, address, baths, beds, rent));
		} catch (IllegalPropertyArgumentException e) {	
			e.printStackTrace();
		}
		
	}
	
	//OPTION 3
	public static void listID(ArrayList<Property> list) {
		
		if(list.size() == 0) {
			System.out.println("There is nothing to list.");
		}
		else {
			Collections.sort(list);
			
			for(Property p: list) {
				System.out.println(p + "\n");
			}
		}
		
	}
	
	//OPTION 4
	public static void listAddress(ArrayList<Property> list) {
		PropertyAddressComparator c = new PropertyAddressComparator();
		if(list.size() == 0) {
			System.out.println("There is nothing to list.");
		}
		else {
			Collections.sort(list, c);

			for(Property p: list) {
				System.out.println(p + "\n");
			}
		}
	}
	
	//OPTION 5
	public static void exitProg(ArrayList<Property> list, File outputFile) {
		
		if(list.size() > 0) {
			
			try (FileOutputStream foStream = new FileOutputStream(outputFile);
		        	 ObjectOutputStream ooStream = new ObjectOutputStream(foStream); ){
				for(int i = 0; i < list.size(); i++) {		
						ooStream.writeObject(list.get(i));
				}
			} catch (FileNotFoundException e) {
				System.out.println("Unable to find specified file.");
				e.printStackTrace();
				System.exit(-1);
			} catch (IOException e) {
				e.printStackTrace();
				System.exit(-1);
			} 
		}
		
		System.out.println("Thank you for using the propety manager program.");
		System.exit(-1);
	}
	

}

