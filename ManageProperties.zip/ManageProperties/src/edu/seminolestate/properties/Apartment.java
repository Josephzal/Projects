//Joseph Lombardo 7/24/2020
package edu.seminolestate.properties;

import java.io.*;;

public class Apartment extends Property implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private double unitRent;

	public Apartment(int newPropertyID, String newAddress, double newNumberOfBaths, 
			int newNumberOfBedrooms, double unitRent) throws IllegalPropertyArgumentException {
		super(newPropertyID, newAddress, newNumberOfBaths, newNumberOfBedrooms);
		this.unitRent = unitRent;
	}

	public double getUnitRent() {
		return unitRent;
	}

	public void setUnitRent(double unitRent) throws IllegalPropertyArgumentException {
		if(unitRent > 0)
			this.unitRent = unitRent;
		else
			throw new IllegalPropertyArgumentException("Rent must be greater than 0.");
	}

	@Override
	public String toString() {
		return super.toString() + " Apartment [Unit Rent = " + unitRent + "]";
	}
	
	
	
	
	
	

}
