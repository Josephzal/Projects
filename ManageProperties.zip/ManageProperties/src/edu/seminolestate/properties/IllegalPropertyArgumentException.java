//Joseph Lombardo 7/24/2020
package edu.seminolestate.properties;

public class IllegalPropertyArgumentException extends Exception{

	private static final long serialVersionUID = 1L;

	public IllegalPropertyArgumentException() {
		super("Illegal argument value sent to Property class");
	}
	
	public IllegalPropertyArgumentException(String message) {
		super(message);
	}

}
