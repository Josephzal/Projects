//Joseph Lombardo 7/24/2020
package edu.seminolestate.properties;

import java.io.*;;

public class House extends Property implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private double lotSize;
	private double value;
	
	
	
	public House(int newPropertyID, String newAddress, double newNumberOfBaths, 
			int newNumberOfBedrooms, double lotSize, double value) 
					throws IllegalPropertyArgumentException {
		super(newPropertyID, newAddress, newNumberOfBaths, newNumberOfBedrooms);
		this.setLotSize(lotSize);
		this.setValue(value);
	}
	public double getLotSize() {
		return lotSize;
	}
	public void setLotSize(double lotSize) throws IllegalPropertyArgumentException {
		if(lotSize > 0)
			this.lotSize = lotSize;
		else
			throw new IllegalPropertyArgumentException("Lot size must be greater than 0.");
	}
	public double getValue() {
		return value;
	}
	public void setValue(double value) throws IllegalPropertyArgumentException {
		if(value > 0)
			this.value = value;
		else
			throw new IllegalPropertyArgumentException("Value must be greater than 0.");
	}
	
	@Override
	public String toString() {
		return super.toString() + " House [Lot Size = " + lotSize + ", Value = " + value + "]";
	}

	
}
