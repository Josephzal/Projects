//Joseph Lombardo 7/24/2020
package edu.seminolestate.properties;

import java.io.*;

public abstract class Property implements Comparable<Property>, Serializable {

	private static final long serialVersionUID = 1L;
	
	private int propertyID;
	private String address;
	private double numberOfBaths;
	private int numberOfBedrooms;

	public Property(int newPropertyID, String newAddress, double newNumberOfBaths, 
			int newNumberOfBedrooms) throws IllegalPropertyArgumentException {
		this.setPropertyID(newPropertyID);
		this.setAddress(newAddress);;
		this.setNumberOfBaths(newNumberOfBaths);
		this.setNumberOfBedrooms(newNumberOfBedrooms);
		
	}
	
	public  int getPropertyID() {
		return propertyID;
	}

	public void setPropertyID(int propertyID) throws IllegalPropertyArgumentException {
		if(propertyID > 0)
			this.propertyID = propertyID;
		else
			throw new IllegalPropertyArgumentException("Property ID must be greater than 0.");
		}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) throws IllegalPropertyArgumentException {
		if(address != null && address.length() > 0)
			this.address = address;
		else
			throw new IllegalPropertyArgumentException("Address cannot be null or have length of 0.");
	}

	public double getNumberOfBaths() {
		return numberOfBaths;
	}

	public void setNumberOfBaths(double numberOfBaths) throws IllegalPropertyArgumentException {
		if(numberOfBaths > 0)
			this.numberOfBaths = numberOfBaths;
		else
			throw new IllegalPropertyArgumentException("Number of baths must be greater than 0.");
	}

	public int getNumberOfBedrooms() {
		return numberOfBedrooms;
	}

	public void setNumberOfBedrooms(int numberOfBedrooms) throws IllegalPropertyArgumentException {
		if(numberOfBedrooms > 0)
			this.numberOfBedrooms = numberOfBedrooms;
		else
			throw new IllegalPropertyArgumentException("Number of bedrooms must be greater than 0.");
	}

	@Override
	public int compareTo(Property obj) {
		return this.propertyID - obj.getPropertyID();
		
	}
	
	@Override
	public String toString() {
		
		return "Property [Property ID = " + propertyID + ", Address = " + address + 
				 ", Number of Baths = " + numberOfBaths + ", Number of Bedrooms = " + numberOfBedrooms + "]";
	}

}
