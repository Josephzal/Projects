//Joseph Lombardo 7/24/2020
package edu.seminolestate.properties;

import java.util.Comparator;

public class PropertyAddressComparator implements Comparator<Property> {

	@Override
	public int compare(Property obj1, Property obj2) {
		int compareResult = obj1.getAddress().compareToIgnoreCase(obj2.getAddress());
		return compareResult;
	}

}
