inventory = {"milk": 3, "bacon": 6, "toilet paper": 4, "gum": 2, "chicken breast": 7,
"avacado": 2, "blueberries": 7, "pasta": 3, "orange juice": 4 }

sCart = []
total = []

print("Hello, welcome to ShopMartStore")
def cashier():
    answer = input("What would you like to purchase from our inventory?\n" ).lower()
    while answer != "quit":
        if answer in inventory:
            sCart.append(answer)
            answer = input("Alrighty, lets put " + answer + " in the cart. \nAnything else today?\n"
                            "( Input 'quit' to end program, or enter item to continue. )\n" ).lower()
            
        else:
            answer = input("Apologies, we do not carry " + answer + ". \nWould you like anything else?\n"
                            "( Input 'quit' to end program, or enter item to continue. )\n" ).lower()
                        
cashier()

print("Items currently in your shopping cart: ", sCart)

answer = input("Would you like to purchase anything else? \n( Input 'yes' or 'no' )\n").lower()

if answer == "yes":
    cashier()
    print("Items currently in your cart: ", sCart)
    for items in sCart:
        total.append(inventory[items])
    amountToPay = sum(total)

else:
    for items in sCart:
        total.append(inventory[items])
    amountToPay = sum(total)

print("Your total amount for today is", amountToPay, "dollars.")